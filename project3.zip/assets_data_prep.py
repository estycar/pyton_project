import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import requests
import time

# משתנים גלובליים לשמירה בין הריצות
preprocessor = None
numeric_medians = {}
default_values = {}
avg_arnona_per_meter = None
building_tax_medians = {}
room_reference_data = None
distance_medians_dict = {}
distance_global_median = None

def prepare_data(data, mode='train'):
    if mode not in ['train', 'test','aplication']:
        raise ValueError("mode must be either 'train' or 'test' or 'aplication'")

    global numeric_medians, default_values
    global avg_arnona_per_meter, building_tax_medians, room_reference_data
    global distance_medians_dict, distance_global_median

    data = data.copy()
    if mode == 'aplication':
    # ערכים נומריים עם ברירת מחדל
        numeric_defaults = {
            'room_num': 3.0,
            'area': 81.5,
            'garden_area': 0.0,
            'monthly_arnona': 485.0,
            'building_tax': 250.0,
            'total_floors': 4.0,
            'floor': 3.0,
            'num_of_images': 6.0,
            'distance_from_center': 1648.0
        }

        for col, default in numeric_defaults.items():
            if col in data.columns:
                data[col] = pd.to_numeric(data[col], errors="coerce").fillna(default)
            else:
                data[col] = default

    # ערכים בינאריים
        binary_columns = [
            'has_parking', 'has_storage', 'elevator', 'ac', 'handicap',
            'has_bars', 'has_safe_room', 'has_balcony',
            'is_furnished', 'is_renovated'
        ]
        for col in binary_columns:
            if col not in data.columns:
                data[col] = 0
            else:
                data[col] = data[col].apply(lambda x: 1 if str(x).lower() in ["on", "1", "true"] else 0)

    # ערכים טקסטואליים עם ברירת מחדל
        text_defaults = {
            'property_type': 'דירה',
            'neighborhood': 'הצפון הישן החלק המרכזי',
            'address': 'לא צוינה כתובת'
        }

        for col, default in text_defaults.items():
            if col not in data.columns:
                data[col] = default
            else:
                data[col] = data[col].fillna(default)

    # שדות משלימים
        data['description'] = ''
        data['days_to_enter'] = 0
        data['num_of_payments'] = 1


    # ----------------------------- TRAIN SECTION -----------------------------
    if mode == 'train':
        data = data.dropna(subset=['price'])
        data = data[data['neighborhood'].notnull() & data['floor'].notnull() & data['address'].notnull()]

        numeric_floor = pd.to_numeric(data['floor'], errors='coerce')
        numeric_medians['floor'] = numeric_floor.median()

        default_values = {
            'property_type': 'דירה',
            'neighborhood': data['neighborhood'].mode()[0],
            'address': data['address'].mode()[0]
        }

        room_reference_data = data.copy()

        data = data[~data['property_type'].isin(['כללי', 'מחסן', 'חניה'])]
        data = data[data['price'].between(2001, 30000)]
        data = data[data['area'] >= 20]

    # ----------------------------- COMMON PREPROCESSING -----------------------------
    data = data.drop(columns=['description', 'days_to_enter', 'num_of_payments'], errors='ignore')

    data[['garden_area', 'handicap', 'num_of_images']] = data[['garden_area', 'handicap', 'num_of_images']].fillna(0)

    data.loc[data['property_type'].isin(["פרטי/קוטג'"]), 'building_tax'] = 0

    data['property_type'] = (
        data['property_type']
        .str.replace('/ ', '/', regex=False)
        .str.replace(' להשכרה', '', regex=False)
        .str.replace('להשכרה', '', regex=False)
        .str.strip()
    )

    allowed_types = ['גג/פנטהאוז', 'דירה', 'דירת גן', 'דופלקס', 'דו משפחתי', 'סאבלט', '"פרטי/קוטג"',
                     'יחידת דיור', 'החלפת דירות', 'סטודיו/לופט', 'מרתף/פרטר']
    data.loc[~data['property_type'].isin(allowed_types), 'property_type'] = 'דירה'

    def extract_real_floor(row):
        floor_str = str(row['floor']).strip()
        total_str = str(row['total_floors']).strip()
        if 'מתוך' in floor_str:
            if 'קרקע' in floor_str:
                return 0
            return pd.to_numeric(floor_str.split(' מתוך ')[0], errors='coerce')
        if floor_str == 'קרקע':
            return 0
        return pd.to_numeric(floor_str, errors='coerce')

    data['floor'] = data.apply(extract_real_floor, axis=1).astype(float)
    data['total_floors'] = data['total_floors'].fillna(data['floor'])

    def fix_floor_values(row):
        if pd.notna(row['floor']) and pd.notna(row['total_floors']) and row['floor'] > row['total_floors']:
            return pd.Series({'floor': row['total_floors'], 'total_floors': row['floor']})
        return pd.Series({'floor': row['floor'], 'total_floors': row['total_floors']})

    data[['floor', 'total_floors']] = data.apply(fix_floor_values, axis=1)

    def impute_rooms_by_area(row):
        if row['room_num'] == 0:
            area = row['area']
            similar = room_reference_data[(room_reference_data['area'].between(area - 5, area + 5)) & (room_reference_data['room_num'] > 0)]
            if not similar.empty:
                return round(similar['room_num'].median())
            fallback = room_reference_data[(room_reference_data['area'].between(area - 2, area)) & (room_reference_data['room_num'] > 0)]
            if not fallback.empty:
                return round(fallback['room_num'].median())
        return row['room_num']

    data['room_num'] = data.apply(impute_rooms_by_area, axis=1)

    def merge_duplicates_and_zero_distance(df, distance_col='distance_from_center'):
        cols_to_check = [col for col in df.columns if col != distance_col]
        duplicate_mask = df.duplicated(subset=cols_to_check, keep=False)
        df_duplicates = df[duplicate_mask].drop_duplicates(subset=cols_to_check).assign(**{distance_col: 0})
        df_unique = df[~duplicate_mask]
        return pd.concat([df_unique, df_duplicates], ignore_index=True)

    data = merge_duplicates_and_zero_distance(data)

    if mode == 'train':
        valid_distance_mask = data['distance_from_center'].notna() & (data['distance_from_center'] > 0) & (data['distance_from_center'] <= 11500)
        distance_medians_dict = data.loc[valid_distance_mask].groupby('neighborhood')['distance_from_center'].median().to_dict()
        distance_global_median = data.loc[valid_distance_mask, 'distance_from_center'].median()

    data['distance_from_center'] = data.apply(
        lambda row: distance_medians_dict.get(row['neighborhood'], distance_global_median)
        if pd.isna(row['distance_from_center']) or row['distance_from_center'] <= 0 or row['distance_from_center'] > 11500
        else row['distance_from_center'], axis=1)

    if 'address' in data.columns:
        data.drop(columns=['address'], inplace=True)

    if mode == 'train':
        valid_rows = data[(data['monthly_arnona'].notna()) & (data['monthly_arnona'] > 0) & (data['area'].notna())].copy()
        valid_rows['arnona_per_meter'] = valid_rows['monthly_arnona'] / valid_rows['area']
        avg_arnona_per_meter = valid_rows['arnona_per_meter'].mean()

    
    if avg_arnona_per_meter is None:
        avg_arnona_per_meter = 6.0  # או כל ערך סביר אחר כגיבוי

    
    data.loc[(data['monthly_arnona'].isna()) | (data['monthly_arnona'] == 0), 'monthly_arnona'] = data['area'] * avg_arnona_per_meter

    def fill_building_tax(df):
        df['area_range'] = (df['area'] // 10) * 10
        if mode == 'train':
            building_tax_medians.clear()
            levels = [
                ('level1', ['neighborhood', 'room_num', 'area_range']),
                ('level2', ['neighborhood']),
                ('level3', ['room_num', 'area_range'])
            ]
            for name, groupby_cols in levels:
                medians = df.groupby(groupby_cols)['building_tax'].median()
                building_tax_medians[name] = (groupby_cols, medians)

        for name, (cols, medians) in building_tax_medians.items():
            idx = df['building_tax'].isnull()
            try:
                df.loc[idx, 'building_tax'] = df[idx].set_index(cols).index.map(medians)
            except:
                continue

        df.drop(columns=['area_range'], inplace=True, errors='ignore')
        return df

    data = fill_building_tax(data)

    if mode == 'train':
        data = data[data['building_tax'].notnull()]

    # ----------------------------- TEST SECTION -----------------------------
    if mode == 'test':
        numeric_floor = pd.to_numeric(data['floor'], errors='coerce')
        numeric_medians['floor'] = numeric_floor.median()
        data['floor'] = data['floor'].where(data['floor'].notna(), numeric_medians['floor'])

        for col, default_val in default_values.items():
            if col in data.columns:
                data[col] = data[col].fillna(default_val)

        safe_defaults = {
            'floor': 3.0,
            'total_floors': 5.0,
            'num_of_images': 6.0,
            'avg_room_size': 20.0,
            'luxury_score': 1.0,
            'monthly_arnona': 500.0,
            'building_tax': 250.0,
            'distance_from_center': 1700.0
        }
        for col, val in safe_defaults.items():
            if col not in data.columns:
                data[col] = val
            else:
                data[col] = data[col].fillna(val)

        data['property_type'] = data['property_type'].replace(['כללי', 'מחסן', 'חניה'], 'דירה')

        if 'building_tax' not in data.columns:
            data['building_tax'] = 0

        for col in data.select_dtypes(include='number').columns:
            if col in numeric_medians:
                data[col] = data[col].fillna(numeric_medians[col])

        for col, default_val in default_values.items():
            if col in data.columns:
                data[col] = data[col].fillna(default_val)

    # ----------------------------- FINAL FEATURES -----------------------------
    def calculate_luxury_score(row):
        floor = row['floor']
        total_floors = row['total_floors']
        has_elevator = row['elevator']
        property_type = row['property_type']

        if property_type in ['פרטי/קוטג׳', 'דו משפחתי']:
            return 1.0
        if total_floors == 0:
            return 1.0

        floor = int(floor)
        total_floors = int(total_floors)

        if has_elevator == 1:
            if floor == 0:
                return 0.95
            elif total_floors == 1:
                return 1.0
            else:
                norm_floor = (floor - 1) / (total_floors - 1)
                bonus = 0.05 * np.log1p(total_floors)
                return round(min(1.0 + norm_floor * bonus, 1.1), 3)
        else:
            if floor == 0:
                penalty = 0.25 * (total_floors / 10)
                return round(max(0.6, 1.0 - penalty), 3)
            else:
                norm_floor = floor / total_floors
                penalty = 0.5 * norm_floor + 0.1 * (total_floors / 10)
                return round(max(0, 1.0 - penalty), 3)

    data['luxury_score'] = data.apply(calculate_luxury_score, axis=1)
    data['avg_room_size'] = data['area'] / data['room_num']

    data.drop(columns=['area'], inplace=True, errors='ignore')
    data.reset_index(drop=True, inplace=True)

    if mode == 'train':
        numeric_medians = data.select_dtypes(include='number').median()
        default_values = {
            'property_type': 'דירה',
            'neighborhood': data['neighborhood'].mode()[0]
        }

    global preprocessor
    if preprocessor is None:
        preprocessor = {}

    if mode == 'train':
        numeric_features_to_scale = [col for col in data.select_dtypes(include=np.number).columns if col != 'price']
        categorical_features_to_encode = data.select_dtypes(include='object').columns.tolist()

        scaler = StandardScaler()
        data[numeric_features_to_scale] = scaler.fit_transform(data[numeric_features_to_scale])
        preprocessor['scaler'] = scaler
        preprocessor['numeric_cols'] = numeric_features_to_scale

        encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
        encoded_array = encoder.fit_transform(data[categorical_features_to_encode])
        encoded_df = pd.DataFrame(encoded_array, columns=encoder.get_feature_names_out(categorical_features_to_encode), index=data.index)

        data.drop(columns=categorical_features_to_encode, inplace=True)
        data = pd.concat([data, encoded_df], axis=1)

        preprocessor['encoder'] = encoder
        preprocessor['categorical_cols'] = categorical_features_to_encode

    elif mode == 'test':
        if not preprocessor:
            raise RuntimeError("Preprocessor has not been fitted yet. Please run with mode='train' first.")

        for col in preprocessor['numeric_cols']:
            if col not in data.columns:
                data[col] = 0

        data_numeric = data[preprocessor['numeric_cols']]
        data[preprocessor['numeric_cols']] = preprocessor['scaler'].transform(data_numeric)

        encoder = preprocessor['encoder']
        for col in preprocessor['categorical_cols']:
            if col not in data.columns:
                data[col] = ''

        encoded_array = encoder.transform(data[preprocessor['categorical_cols']])
        encoded_df = pd.DataFrame(encoded_array, columns=encoder.get_feature_names_out(preprocessor['categorical_cols']), index=data.index)

        data.drop(columns=preprocessor['categorical_cols'], inplace=True)
        data = pd.concat([data, encoded_df], axis=1)

    elif mode == 'aplication':
        if not preprocessor:
            raise RuntimeError("Preprocessor has not been fitted yet. Please run with mode='train' first.")

        for col in preprocessor['numeric_cols']:
            if col not in data.columns:
                data[col] = 0

        data_numeric = data[preprocessor['numeric_cols']]
        data[preprocessor['numeric_cols']] = preprocessor['scaler'].transform(data_numeric)

        encoder = preprocessor['encoder']
        for col in preprocessor['categorical_cols']:
            if col not in data.columns:
                data[col] = ''

        encoded_array = encoder.transform(data[preprocessor['categorical_cols']])
        encoded_df = pd.DataFrame(encoded_array, columns=encoder.get_feature_names_out(preprocessor['categorical_cols']), index=data.index)

        data.drop(columns=preprocessor['categorical_cols'], inplace=True)
        data = pd.concat([data, encoded_df], axis=1)


    return data

import pandas as pd
import pickle
from sklearn.linear_model import ElasticNetCV
import assets_data_prep
from assets_data_prep import prepare_data

# קריאה לדאטה וניקוי עמודות ריקות
train_df = pd.read_csv("train.csv").dropna(axis=1, how="all")

# עיבוד הנתונים
prepared = prepare_data(train_df, mode="train")
X = prepared.drop(columns=["price"])
y = prepared["price"]

# הגדרת ואימון המודל
model = ElasticNetCV(alphas=[0.01], l1_ratio=[0.99], cv=10, max_iter=5000, random_state=42)
model.fit(X, y)

# שמירת סדר העמודות
feature_order = X.columns.tolist()

# שמירת המודל והכל
bundle = {
    "model": model,
    "preprocessor": assets_data_prep.preprocessor,
    "numeric_medians": assets_data_prep.numeric_medians,
    "default_values": assets_data_prep.default_values,
    "avg_arnona_per_meter": assets_data_prep.avg_arnona_per_meter,
    "building_tax_medians": assets_data_prep.building_tax_medians,
    "feature_order": feature_order
}

with open("trained_model.pkl", "wb") as f:
    pickle.dump(bundle, f)

print("✅ המודל נשמר בהצלחה עם preprocessor ו-feature_order.")

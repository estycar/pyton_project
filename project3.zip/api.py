from flask import Flask, render_template, request
import pandas as pd
import pickle
import assets_data_prep

app = Flask(__name__)

# טעינת המודל והכל מה-bundle
with open("trained_model.pkl", "rb") as f:
    bundle = pickle.load(f)

model = bundle["model"]
feature_order = bundle["feature_order"]

# עדכון כל המשתנים הגלובליים בקובץ העיבוד
assets_data_prep.preprocessor = bundle["preprocessor"]
assets_data_prep.numeric_medians = bundle["numeric_medians"]
assets_data_prep.default_values = bundle["default_values"]
assets_data_prep.avg_arnona_per_meter = bundle["avg_arnona_per_meter"]
assets_data_prep.building_tax_medians = bundle["building_tax_medians"]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    form = request.form.to_dict()
    df = pd.DataFrame([form])

    # עיבוד מלא של הקלט
    processed = assets_data_prep.prepare_data(df, mode="aplication")

    # התאמה לסדר וסוג העמודות של המודל
    processed = processed.reindex(feature_order, axis=1, fill_value=0)

    prediction = model.predict(processed)[0]
    return render_template("index.html", prediction_text=f"חיזוי מחיר משוער: {round(prediction):,} ₪",
                       form_values=form)



if __name__ == "__main__":
    app.run(debug=True)
